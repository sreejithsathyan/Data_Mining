# -*- coding: utf-8 -*-
import scrapy
from books_toscrape.items import BooksToscrapeItem

class BooksToscrapeSpidersSpider(scrapy.Spider):
    name = 'books_toscrape_spiders'
    allowed_domains = ['http://books.toscrape.com']
    lines=[]
    text_file = open("urls.txt", "r")
    lines = text_file.read().split("\n")
    print lines
    text_file.close()
    start_urls = lines#['http://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.html']
    def parse(self, response):
    	title = response.xpath('//div[@class="col-sm-6 product_main"]/h1/text()').extract_first()
    	print title
    	price = response.xpath('//div[@class="col-sm-6 product_main"]/p/text()').extract_first()
    	print price
    	stock_status = response.xpath('//div[@class="col-sm-6 product_main"]/p/text()').extract()[2].split()
    	stock_status= '-'.join(stock_status)
    	print stock_status
    	rating = response.xpath('//div[@class="col-sm-6 product_main"]/p/@class').extract()[2]
    	print rating
    	category = response.xpath('//ul[@class="breadcrumb"]//a/text()').extract()[2]
    	print category

        item = BooksToscrapeItem(
            title=title,
            price=price,
            stock_status=stock_status,
            rating=rating,
            category=category)
        yield item
   
