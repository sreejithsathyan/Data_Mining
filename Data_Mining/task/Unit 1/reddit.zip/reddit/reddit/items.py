# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class RedditItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    title1=scrapy.Field()
    book_url2=scrapy.Field()
    score3=scrapy.Field()
    usser_name4=scrapy.Field()
    time5=scrapy.Field()
    usser_link6=scrapy.Field()
    
