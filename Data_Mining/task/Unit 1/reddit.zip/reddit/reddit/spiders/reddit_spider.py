# -*- coding: utf-8 -*-
import scrapy
from reddit.items import RedditItem

class RedditSpiderSpider(scrapy.Spider):
    name = 'reddit_spider'
    allowed_domains = ['www.reddit.com']
    start_urls = ['https://www.reddit.com/r/programming/','https://www.reddit.com/r/Python/']

    def parse(self, response):
        book_selector=response.xpath('//div[@id="siteTable"]/div[@id]')
        for book in book_selector:
            title=book.xpath('div//p[@class="title"]/a/text()').extract_first()
            print title
            book_url=book.xpath('div[@class="entry unvoted"]/div/p[@class="title"]/a/@href').extract()
            print book_url
            score=book.xpath('div//div[@class="score unvoted"]/text()').extract_first()
            print score
            usser_link=book.xpath('div[@class="entry unvoted"]/div/p[@class="tagline "]/a/@href').extract_first()
            print usser_link
            usser_name=book.xpath('div[@class="entry unvoted"]/div/p[@class="tagline "]/a/text()').extract_first()
            print usser_name
            time = book.xpath('div[@class="entry unvoted"]/div/p[@class="tagline "]/time[@class="live-timestamp"]/text()').extract_first()
            #time=str(time)
            print time

            item = RedditItem(
                title1=title,
                book_url2=book_url,
                score3=score,
                usser_name4=usser_name,
                time5=time,
                usser_link6=usser_link,)
            yield item

