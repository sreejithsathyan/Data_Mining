# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import HtmlXPathSelector
from scrapy.http import FormRequest
from news.items import NewsItem
class NewsSpiderSpider(scrapy.Spider):
    name = 'news_spider'
    allowed_domains = ['news.ycombinator.com']
    start_urls = ['https://news.ycombinator.com/login']

    def parse(self, response):
        url = "https://news.ycombinator.com/login"
        yield FormRequest.from_response(response,formdata={'acct':'scrape1123','pw':'scrape1123'},callback=self.after_login)
    
    def after_login(self, response):
        print response.url
        own_usser_name = response.xpath('//span[@class="pagetop"]/a/text()').extract()[7]
        # print own_usser_name
        # title = response.xpath('//td[@class="title"]/a/text()').extract_first()
        # print title
        # url = response.xpath('//td[@class="title"]/a/@href').extract()
        # print url
        # score = response.xpath('//td[@class="subtext"]/span/text()').extract()
        # print score
        # usser_name =  response.xpath('//td[@class="subtext"]/a[1]/text()').extract()
        # print usser_name
        # time = response.xpath('//span[@class="age"]/a/text()').extract()
        # print time
        # comment_count =  response.xpath('//td[@class="subtext"]/a[3]/text()').extract()
        # print comment_count
        # item = NewsItem(title = title,
        #         url = title,
        #         score = score,
        #         usser_name = usser_name,
        #         time = time,
        #         comment_count = comment_count
        #         )
        # yield item  
