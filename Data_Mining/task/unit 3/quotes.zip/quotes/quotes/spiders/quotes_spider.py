# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import HtmlXPathSelector
from scrapy.http import FormRequest
from scrapy.shell import inspect_response
from quotes.items import QuotesItem
class QuotesSpiderSpider(scrapy.Spider):
    name = 'quotes_spider'
    allowed_domains = ['quotes.toscrape.com']
    start_urls = ['http://quotes.toscrape.com/search.aspx']

    def parse(self, response):
        authors = response.xpath('//select[@class="form-control"]//option/@value').extract()
        #print authors
        view_state = response.xpath('//input[@type="hidden"]/@value').extract_first()
        url = 'http://quotes.toscrape.com/filter.aspx'
        for author in authors:
            meta = {'author':author}
            
            yield FormRequest(url=url, formdata={'author':author,'tag':'----------','__VIEWSTATE':view_state},callback=self.after_author, meta=meta)
    def after_author(self, response):
        #inspect_response(response, self)
        url = 'http://quotes.toscrape.com/filter.aspx'
        author = response.meta['author']
        search = response.xpath('//input[@name="submit_button"]/@value').extract()
        tags = response.xpath('//select[@id="tag"]//option/@value').extract()
        view_state = response.xpath('//input[@type="hidden"]/@value').extract_first()
        print ">>>>>>>>>>>>>>>>>>>"
        for tag in tags:
            meta = {'author':author,'tag':tag}
            yield FormRequest(url=url, formdata={'author':author,'tag':tag,'__VIEWSTATE':view_state},callback=self.contents,meta=meta)
            
    def contents(self,response):
        author = response.meta['author']
        tag = response.meta['tag']
        #inspect_response(response, self)
        content = response.xpath('//div[@class="quote"]/span[@class="content"]/text()').extract()
        #print content
        item = QuotesItem(content = content,
                          author = author,
                          tag = tag)
        yield item
        