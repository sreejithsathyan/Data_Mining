# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import Request
from scrapinghub.items import ScrapinghubItem
class ScrapinghubSpiderSpider(scrapy.Spider):
	name = 'scrapinghub_spider'
	allowed_domains = ['blog.scrapinghub.com']
	start_urls = ['http://blog.scrapinghub.com/']
	#start_urls = ['https://blog.scrapinghub.com/page/2/']
	def parse(self, response):
		urls = response.xpath('//h2[@class="entry-title"]/a/@href').extract()
		for url in urls:
			yield scrapy.Request(url=url,callback = self.parse_urls)
		next_url = response.xpath('//div[@class="col-md-6 prev-post"]/a/@href').extract_first()
		if next_url:
			yield Request(url=next_url,callback=self.parse)

	def parse_urls(self, response):
		#print '@222222222222222222222222222222222222222222222222222222222',response.url
		title = response.xpath('//span[@class="screen-reader-text"]/text()').extract_first()
		print title
		author = response.xpath('//span[@class="author vcard"]/a/text()').extract()
		print author
		date = response.xpath('//time[@class="entry-date"]/text()').extract()
		print date
		tag = tag = response.xpath('//div[@class="col-md-6 tags"]/span/a/text()').extract()
		tag = ' '.join(tag)
		print tag
		item = ScrapinghubItem(title = title,
							   author = author,
							   date = date,
							   tag = tag)
		if tag:
			yield item
