# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import Request
from books.items import BooksItem
class BooksSpiderSpider(scrapy.Spider):
	name = 'books_spider'
	#allowed_domains = ['books.toscrape.com/']
	start_urls = ['http://books.toscrape.com']

	def parse(self, response):
		books=response.xpath('//li[@class="col-xs-6 col-sm-4 col-md-3 col-lg-3"]')
		

		for book in books:
			title = book.xpath('article/h3/a/@title').extract_first()
			#print title
			price = book.xpath('article/div[@class="product_price"]/p/text()').extract_first()
			price = price.encode("utf8")
			price = float(price.replace('£', ''))
			#print price
			stock_status = book.xpath('article/div[@class="product_price"]/p/@class').extract()[1]
			#print stock_status
			item = BooksItem(
				title=title,
				price=price,
				stock_status=stock_status)
			yield item


		#domain = ['http://books.toscrape.com/']
		#print domain
		next_domain = response.xpath('//li[@class="next"]/a/@href').extract_first()
		#print next_domain
		#next_domain = domain+next_domain

		#print next_domain
		#next_domain = ''.join(next_domain)
		#print next_domain
		next_domain = response.urljoin(next_domain)
		print next_domain
		yield Request(url=next_domain,callback=self.parse)

		
   